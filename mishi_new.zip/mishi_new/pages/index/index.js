var app = getApp();
var QQMapWX = require('../../utils/qqmap-wx-jssdk.min.js')
var qqmap = new QQMapWX({ key: "XSYBZ-P2G34-3K7UB-XPFZS-TBGHT-CXB4U" })

var dialog_ad_url_g = '';

var winHeight1 = 0;
var winHeight2 = 0;
var nav_width = 0;

var time = 0;
var interval = "";
var touchDot = 0;
var flag = false;

///全局 是否正在加载中 仅用于前端 如果已经在加载的时候，不要二次加载。释放后才可以继续下拉
var isLoading = false;

var token

var bonus_pos;

Page({
  data: {
    adshow: false,

    dialog_ad_url: '',
    dialog_ad_image: '',

    indexdata: [],

    iphoneView: true,
    hidden: false,
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    scrollTop: 0,
    nav_w: 0, //顶部导航栏宽度
    scrollLeftValue: 0,
    activityLeft: [],//左广告位
    activityRight: [], //右广告位
    hasLocation: false,

    ////////////
    currentTab: 0,
    toView: "index",
    sorllView: [],
    winHeight: "",//窗口高度
    /////////////////////
    navstatus: true,

    lastX: 0,
    lastY: 0,
    currentGesture: 0,

    navList: [
      {
        icon: "../../images/new_nav_1.png",
        name: "砍价商城",
        link: "../bargain/index"
      },
      {
        icon: "../../images/new_nav_2.png",
        name: "米时拼团",
        link: "../group/index"
      },
      {
        icon: "../../images/new_nav_3.png",
        name: "我的代言",
        link: "../user/speak"
      },
      {
        icon: "../../images/new_nav_4.png",
        name: "店铺",
        link: "../user/collect_shop"
      }
    ],
    showBonus: false,
    bonusInfo: [],
    shopInfo: [],
    redBonus: [],
    animation: '',
    animationBt: '',
    animationS: '',
    openbonus: false,
    openedbonus: false,
  },
  onLoad: function () {
    app.editTabBar(); 
    //app.myAdData.isIndexAdShow
    // app.getOpenIdTap(); //测试
    var gzid = app.getCurrentPageOption().gzid;

    if (gzid != undefined) {
      console.log("写入广告记录");
      ////写入广告记录。  
      app.addGzid(gzid, 0);
    }

    var that = this;

    //获取窗口高度
    wx.getSystemInfo({
      success: function (res) {
        var clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = 750 / clientWidth;
        nav_width = clientWidth / 6;
        var calc = clientHeight * rpxR - 80;
        winHeight1 = calc;
        winHeight2 = calc + 80;
        that.setData({
          winHeight: calc,
          nav_w: clientWidth
        });
      }
    });

    //初始化onLoad
    var token = wx.getStorageSync('token')
    //console.log(app.apiUrl('index'));


    console.log("开始加载：" + new Date());

    wx.request
      ({
        url: app.apiUrl("index"),
        method: "POST",
        header: {
          'Content-Type': 'application/json',
          'X-ECTouch-Authorization': token
        },
        success: function (res) {
          //获取当前导航  this.data.currentTab
          console.log("结束加载：" + new Date());

          //var isHasdialogAd = res.data.data.is_dialog_ad;

          var isHasdialogAd = res.data.data.nav_list[that.data.currentTab].is_dialog_ad;

          var isadshow = false;

          var dialog_ad_url_t = '';
          var dialog_ad_image_t = '';

          if (isHasdialogAd == '1') {
            console.log("存在首页窗口广告");

            if (app.myAdData.isIndexAdShow) {
              isadshow = false;
            }
            else {
              isadshow = true;
              app.myAdData.isIndexAdShow = true;//设置为已经显示。
            }


            // dialog_ad_url_g = res.data.data.dialog_ad.ext_url;
            dialog_ad_url_g = res.data.data.nav_list[that.data.currentTab].dialog_ad.ext_url;
            console.log("存在首页窗口广告::" + dialog_ad_url_g);

            //dialog_ad_url_t = res.data.data.dialog_ad.ext_url;
            dialog_ad_url_t = res.data.data.nav_list[that.data.currentTab].dialog_ad.ext_url;
            dialog_ad_image_t = res.data.data.nav_list[that.data.currentTab].dialog_ad.ad_image;

          }
          else {
            // console.log("不存在首页窗口广告"); 
          }
          that.setData
            ({
              index: res.data.data,
              indexdata: res.data.data,//循环中冲突，自定义了一个indexdata
              sorllView: res.data.data.nav_list,
              activityLeft: res.data.data.adsense[0],
              activityRight: res.data.data.adsense.splice(1, 2),
              adshow: isadshow,
              dialog_ad_url: dialog_ad_url_t,
              dialog_ad_image: dialog_ad_image_t

            })
          that.getBonus(that.data.sorllView[0].nav_id);
        }
      })

    //加载中
    this.loadingChange();
    // that.getLocation();
    that.onChangeShowIphone();
  },

  onShow:function(){
    app.hideTabbar();
  },
  onReady: function () {
    this.animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'ease',
      delay: 100,
      transformOrigin: 'left top 50',
      success: function (res) {
        console.log(res)
      }
    });
    this.animationBt = wx.createAnimation({
      duration: 50,
      timingFunction: 'linear',
      success: function (res) {
        console.log(res)
      }
    })
    this.animationS = wx.createAnimation({
      duration: 300,
      timingFunction: 'ease',
      success: function (res) {
        console.log(res)
      }
    })
  },

  //点击顶部导航栏
  selectScroll: function (e) {
    var cur = e.target.dataset.current;
    var left = cur * nav_width;

    /////////////////////////模拟懒加载
    var that = this
    that.data.sorllView[cur].is_init = '1';

    //cyc
    var pos = that.data.sorllView[cur].nav_id;
    this.getBonus(pos);
    //cyc

    /* 
      that.setData
        ({
          sorllView: that.data.sorllView
        })
    */
    ////////////////////////////////////////////
    console.log("点击到了" + cur);

    var isHasdialogAd = that.data.index.nav_list[cur].is_dialog_ad;

    var isadshow = false;

    var dialog_ad_url_t = '';
    var dialog_ad_image_t = '';

    if (isHasdialogAd == '1') {
      console.log("存在首页窗口广告");

      if (app.myAdData.isIndexAdShow) {
        isadshow = false;
      }
      else {
        isadshow = true;
        app.myAdData.isIndexAdShow = true;//设置为已经显示。
      }


      // dialog_ad_url_g = res.data.data.dialog_ad.ext_url;
      dialog_ad_url_g = that.data.index.nav_list[cur].dialog_ad.ext_url;
      console.log("点击存在首页窗口广告::" + dialog_ad_url_g);

      //dialog_ad_url_t = res.data.data.dialog_ad.ext_url;
      dialog_ad_url_t = that.data.index.nav_list[cur].dialog_ad.ext_url;
      dialog_ad_image_t = that.data.index.nav_list[cur].dialog_ad.ad_image;

    }


    this.setData({

      currentTab: cur,

      // toView: view,

      adshow: isadshow,
      dialog_ad_url: dialog_ad_url_t,
      dialog_ad_image: dialog_ad_image_t,
      sorllView: that.data.sorllView
    });

    /////////////////////////////////////////



    this.autoScrollTopNav(left);

    if (this.data.currentTab == cur) {
      return false;
    }
    else {
      for (var i = 0; i < this.data.sorllView.length; i++) {
        if (e.currentTarget.id === this.data.sorllView[i].id) {
          this.setData({
            currentTab: cur,
            toView: e.currentTarget.id
          })
        }
      }
    }
  },
  autoScrollTopNav: function (pos) {
    var scrollLeft = 0;
    pos = pos > this.data.nav_w / 2 ? pos - this.data.nav_w / 2 + 10 : 0

    this.setData({
      scrollLeftValue: pos
    })
  },

  gotest: function (e) {
    var cur = e.target.dataset.current;

    wx.navigateTo
      ({
        url: 'test'
      })
  },

  //dialog ad
  dialog_ad_click: function (e) {
    console.log("点击了窗口广告");
    if (dialog_ad_url_g != '') {
      wx.navigateTo
        ({
          url: dialog_ad_url_g
        })
    }

  },



  //滑动切换页面
  switchTab: function (e) {
    if (!e.detail.source) {
      return;
    }

    var view = this.data.sorllView[e.detail.current].id;

    var cur = e.detail.current;
    var left = cur * nav_width;
    this.autoScrollTopNav(left);

    this.setData
      ({
        navstatus: true,
        winHeight: winHeight1
      })


    console.log("滑动到了" + cur);

    var that = this

    /////////////////////////模拟懒加载
    that.data.sorllView[cur].is_init = '1';

    /*
     that.setData
       ({
         sorllView: that.data.sorllView
       })
  */
    ////////////////////////////////////////////

    //cyc
    var pos = that.data.sorllView[cur].nav_id;
    this.getBonus(pos);
    //cyc

    var isHasdialogAd = that.data.index.nav_list[cur].is_dialog_ad;



    var isadshow = false;

    var dialog_ad_url_t = '';
    var dialog_ad_image_t = '';

    if (isHasdialogAd == '1') {
      console.log("存在首页窗口广告");

      if (app.myAdData.isIndexAdShow) {
        isadshow = false;
      }
      else {
        isadshow = true;
        app.myAdData.isIndexAdShow = true;//设置为已经显示。
      }


      // dialog_ad_url_g = res.data.data.dialog_ad.ext_url;
      dialog_ad_url_g = that.data.index.nav_list[cur].dialog_ad.ext_url;
      console.log("存在首页窗口广告::" + dialog_ad_url_g);

      //dialog_ad_url_t = res.data.data.dialog_ad.ext_url;
      dialog_ad_url_t = that.data.index.nav_list[cur].dialog_ad.ext_url;
      dialog_ad_image_t = that.data.index.nav_list[cur].dialog_ad.ad_image;

    }


    this.setData({

      currentTab: e.detail.current,
      toView: view,

      adshow: isadshow,
      dialog_ad_url: dialog_ad_url_t,
      dialog_ad_image: dialog_ad_image_t,
      sorllView: that.data.sorllView
    });

  },




  //定位
  chooseLocation: function () {
    var that = this
    var token = wx.getStorageSync('token')
    wx.chooseLocation({
      success: function (res) {
        wx.setStorageSync('currentPosition', res)
        var lat = res.latitude;
        var lon = res.longitude;
        qqmap.reverseGeocoder({
          location: {
            latitude: lat,
            longitude: lon
          },
          success: function (res) {
            wx.request({
              url: app.apiUrl('location/specific'),
              data: {
                address: res.result.address_component.city,
              },
              method: 'POST',
              header: {
                'Content-Type': 'application/json',
                'X-ECTouch-Authorization': token
              },
              success: function (res) {
                that.setData({
                  address: res.address,
                })
              }
            })
            var addess
            if (res.result.address_component.province == res.result.address_component.city) {
              addess = res.result.address_component.city
            } else {
              addess = res.result.address_component.city
            }
            that.setData({
              hasLocation: true,
              address: addess,
            })
          },
          fail: function (res) {
          },
        });

      }
    })
  },
  //获取当前定位
  getLocation: function () {
    var that = this
    wx.getLocation({
      success: function (res) {
        //缓存当前位置坐标
        var value = wx.getStorageSync('currentPosition')
        if (value) {
          that.transformRegion(value)
        } else {
          wx.setStorageSync('currentPosition', res)
          that.transformRegion(res)
        }
      },
      fail: function (res) {
        wx.showModal({
          title: '温馨提示',
          content: '不允许定位,会对地区商品价格有影响，请确认，去重新允许！',
          success: function (res) {
            if (res.confirm) {
              wx.getSetting({
                success(res) {
                  wx.openSetting({
                    success: function (res) {
                      if (!res.authSetting["scope.userLocation"]) {
                        that.getLocation()
                      } else {
                        wx.getLocation({
                          success: function (res) {
                            //缓存当前位置坐标
                            var value = wx.getStorageSync('currentPosition')
                            if (value) {
                              that.transformRegion(value)
                            } else {
                              wx.setStorageSync('currentPosition', res)
                              that.transformRegion(res)
                            }
                          },
                        })
                      }
                    }
                  })
                },
              })
            } else if (res.cancel) {
              that.getLocation()
            }
          },
        })
      },
    })
  },
  transformRegion: function (res) {
    var that = this
    var lat = res.latitude;
    var lon = res.longitude;
    qqmap.reverseGeocoder({
      location: {
        latitude: lat,
        longitude: lon
      },
      success: function (res) {
        var addess
        if (res.result.address_component.province == res.result.address_component.city) {
          addess = res.result.address_component.city
        } else {
          addess = res.result.address_component.city
        }
        that.setData({
          hasLocation: true,
          address: addess,
        })
      },
      fail: function (res) {
      },
    });
  },
  //返回顶部
  goTop: function (e) {
    this.setData({
      scrollTop: 0
    })
  },



  scroll: function (e) {
    if (e.detail.scrollTop > 450) {


      flag = true;
    } else {

      flag = false;
    }



    this.setData({
      indexSearch: e.detail.scrollTop
    });
    if (e.detail.scrollTop > 300) {
      this.setData({
        floorstatus: true,

      });
    } else {
      this.setData({
        floorstatus: false,

      });
    }
  },
  //获取点击的id值
  siteDetail: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index;

    console.log("index:" + index);

    console.log(that.data.sorllView[that.data.currentTab])

    var goodsId = that.data.sorllView[that.data.currentTab].goods_list[index].goods_id;
    // app.getUserInfo(function (userInfo) {
    //   that.setData({
    //     userInfo: userInfo
    //   })
    // })
    wx.navigateTo({
      url: "../goods/index?objectId=" + goodsId// + "&gzid=1&cash=ondelivery&gdt_vid=1231231"
    });
  },
  //////非首屏
  siteDetail2: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index;//当前屏中商品的位置。

    // console.log(e);

    //console.log(that.data.currentTab); 

    // console.log(that.data.index.nav_list[that.data.currentTab].goods_list[index].goods_id); 



    var goodsId = that.data.sorllView[that.data.currentTab].goods_list[index].goods_id;   //that.data.index.goods_list[index].goods_id;

    console.log(goodsId);

    // app.getUserInfo(function (userInfo) {
    //   that.setData({
    //     userInfo: userInfo
    //   })
    // })
    wx.navigateTo({
      url: "../goods/index?objectId=" + goodsId
    });

  },


  onChangeShowIphone: function () {
    var that = this;
    that.setData({
      iphoneView: (!that.data.iphoneView)
    })
  },
  //绑定手机号
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
  },

  //点数收集
  formSubmitAD: function (e) {
    this.setData({
      adshow: false
    })

    var formID = e.detail.formId;


    console.log("index 中::" + wx.getStorageSync('openid'));

    app.addFormId(formID);

    //
    //  this.dialog_ad_click();

  },
  formSubmitAD2: function (e) {
    this.setData
      ({
        adshow: false
      })

    var formID = e.detail.formId;
    console.log(formID);

    console.log("index2222 中::" + wx.getStorageSync('openid'));

    app.addFormId(formID);

    //
    this.dialog_ad_click();

  },
  formSubmitAD3: function (e) {
    this.setData
      ({
        adshow: false
      })

    var formID = e.detail.formId;

    //console.log("index333 中::" + e.currentTarget.dataset.url);//OK!!! 这样自定义传递数据非常方便
    console.log("index333 中::" + wx.getStorageSync('openid'));

    app.addFormId(formID);

    var targetUrl = e.currentTarget.dataset.url;

    if (targetUrl != '') {
      wx.navigateTo
        ({
          url: '' + targetUrl
        })
    }

  },
  formReset: function () {
    console.log('form发生了reset事件')
  },

  // 搜索链接
  bindSearchTap: function () {
    wx.navigateTo({
      url: '../search/index'
    })
  },

  bindCateTap: function () {
    wx.switchTab({
      url: '../category/index'
    })
  },
  //菜单
  cate_nav: function (e) {
    var cont = e.currentTarget.dataset.index;
    if (cont == "0") {
      wx.navigateTo({
        url: '../user/coupons',
      });
    } else if (cont == "1") {
      wx.navigateTo({
        url: '../user/speak',
      });
    } else if (cont == "2") {
      wx.navigateTo({
        url: '../user/collect_shop',
      });
    } else if (cont == "3") {
      wx.switchTab({
        url: '../category/index',
      });
    } else if (cont == "4") {
      wx.navigateTo({
        url: '../scan-code/index',
      });
    }
  },
  loadingChange() {
    setTimeout(() => {
      this.setData({
        hidden: true
      })
    }, 1000)
  },
  //下拉刷新完后关闭
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
  },
  //分享
  onShareAppMessage: function () {
    var title = '米时全球品牌工厂直销平台';
    if (this.data.openedbonus) {
      title = '红包领取成功'
    }
    return {
      title: title,
      desc: '小程序本身无需下载，无需注册，不占用手机内存，可以跨平台使用，响应迅速，体验接近原生App',
      path: '/pages/index/index'
    }
  },

  bindDownLoad: function () {
    var that = this;

    var nowIndex = that.data.currentTab;

    //console.log('--------下拉刷新-------:' + nowIndex);

    var isHasMore = that.data.sorllView[nowIndex].is_has_more;

    if (isHasMore == '0' || isLoading) {
      // console.log('--------下拉刷新--不存在更多-----:' + nowIndex);
      return;

    }

    isLoading = true;

    // console.log('--------下拉刷新-存在更多------:' + nowIndex);


    that.data.sorllView[nowIndex].is_loading_more = '1';


    this.setData
      ({
        sorllView: that.data.sorllView
      })

    /**/

    var token = wx.getStorageSync('token')

    wx.request
      ({
        url: app.apiUrl('index/loadmore'),//app.apiUrlMy('m=site&c=index&a=test'),  //app.apiUrl('user/logina'),//
        data:
        {
          cate_id: that.data.sorllView[nowIndex].cate_id,
          page_now: that.data.sorllView[nowIndex].page_now
        },

        method: 'get',
        header:
        {
          'Content-Type': 'application/json',
          //"Content-Type": "application/x-www-form-urlencoded"  POST用这个
          'X-ECTouch-Authorization': token
        },
        success: function (res) {
          isLoading = false;

          console.log("当前的页码是 ：" + that.data.sorllView[nowIndex].page_now);

          //console.log('--------下拉刷新--加载成功xxxxx-----:' + res.data.data.is_has_more); 
          // console.log('--------下拉刷新--加载成功yyyyy-----:' + res.data.data.goods_list); 

          that.data.sorllView[nowIndex].is_loading_more = '0';

          that.data.sorllView[nowIndex].goods_list = that.data.sorllView[nowIndex].goods_list.concat(res.data.data.goods_list);

          that.data.sorllView[nowIndex].page_now = that.data.sorllView[nowIndex].page_now + 1;

          that.data.sorllView[nowIndex].is_has_more = res.data.data.is_has_more;

          //console.log('--------下拉刷新--加载成功-----:' + nowIndex);

          that.setData
            ({
              sorllView: that.data.sorllView
            })
        },
        fail: function (err) {
          isLoading = false;

          //console.log('--------下拉刷新--加载失败-----:' + nowIndex);

          that.data.sorllView[nowIndex].is_has_more = "0";

          that.data.sorllView[nowIndex].is_loading_more = '0';
          that.setData
            ({
              sorllView: that.data.sorllView
            })
        }
      })

  },


  // 触摸开始事件  
  touchStart: function (e) {
    touchDot = e.touches[0].pageY; // 获取触摸时的原点  
  },
  // 触摸移动事件  
  touchMove: function (e) {
    var touchMove = e.touches[0].pageY;
    // 向上滑动    
    if (touchMove - touchDot <= -40) {
      if (this.data.winHeight == winHeight2) return;
      if (!flag) return;
      this.setData
        ({
          navstatus: false,
          winHeight: winHeight2
        })
    }
    // 向下滑动  
    if (touchMove - touchDot >= 40) {
      if (this.data.winHeight == winHeight1) return;
      this.setData
        ({
          navstatus: true,
          winHeight: winHeight1
        })
    }
  },
  // 触摸结束事件  
  touchEnd: function (e) {
    time = 0;
  },

  test: function () {
    var token = wx.getStorageSync('token')

    wx.request({
      url: app.apiUrl('bonus/info'),
      method: "POST",
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      success: function (res) {

      }
    })
  },

  //获取红包数据
  getBonus: function (pos) {
    bonus_pos = pos;
    var that = this;
    var token = wx.getStorageSync('token');
    wx.request({
      url: app.apiUrl("bonus/info"),
      method: "POST",
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      data: {
        ad_id: 1,
        pos_id: pos,
        ad_type: 'home'
      },
      success: function (res) {
        if (res.data.data.bn_info > 0) {
          var shopInfo = res.data.data.shop_info;
          if (!shopInfo.logo_thumb) {
            shopInfo.logo_thumb = '../../images/logo.png';
          }

          that.setData({
            showBonus: true,
            bonusInfo: res.data.data.ad_info,
            shopInfo: shopInfo,
          })
        } else {
          that.setData({
            showBonus: false,
          })
        }
      }
    })
  },
  //显示红包动作
  showBonusAction: function () {
    this.checkBonus();
  },
  //打开红包动作
  openBonusAction: function () {
    var that = this;
    var i = 0;
    var time = setInterval(function () {
      if (i % 2 == 0) {
        if (i == 0) {
          that.animationBt.translateX(2.5).step();
          that.setData({
            animationBt: that.animationBt.export()
          });
        } else {
          that.animationBt.translateX(5).step();
          that.setData({
            animationBt: that.animationBt.export()
          });
        }
      } else {
        that.animationBt.translateX(-5).step();
        that.setData({
          animationBt: that.animationBt.export()
        });
      }
      i++;
    }, 50)

    that.receiveBonus(time);

  },
  closeBonusAction: function () {
    this.animation.top("-870rpx").step();
    this.setData({
      openbonus: false,
      openedbonus: false,
      animation: this.animation.export()
    });
  },
  checkBonus: function () {
    var that = this;
    var token = wx.getStorageSync('token');
    wx.request({
      url: app.apiUrl("bonus/receive"),
      method: "POST",
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      data: {
        ad_id: 1,
        pos_id: bonus_pos,
        open_id: wx.getStorageSync('openid'),
        ad_type: 'check'
      },
      success: function (res) {
        if (res.data.data) {
          that.setData({
            openbonus: false,
            openedbonus: true,
            showBonus: false,
            redBonus: res.data.data,
          });
        } else {
          that.animation.top("12%").step();
          that.setData({
            openbonus: true,
          });
          that.setData({
            animation: that.animation.export()
          });
        }
      }
    })
  },
  //领取红包
  receiveBonus: function (t) {
    var that = this;
    var token = wx.getStorageSync('token');
    wx.request({
      url: app.apiUrl("bonus/receive"),
      method: "POST",
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      data: {
        ad_id: 1,
        pos_id: bonus_pos,
        open_id: wx.getStorageSync('openid'),
        ad_type: 'home'
      },
      success: function (res) {
        clearInterval(t);
        that.animationBt.translateX(0).step();
        that.setData({
          animationBt: that.animationBt.export()
        });
        that.setData({
          openbonus: false,
          openedbonus: true,
          showBonus: false,
          redBonus: res.data.data,
        });
      }
    })
  },
  shareBonus: function () {
    this.onShareAppMessage()
  },
  //阻止滑动穿透
  catchTouch: function () {
    return;
  },
  submitFormId: function (e) {
    var formID = e.detail.formId;
    console.log(formID);
    app.addFormId(formID);
  },
  getUser: function (res) {
    if (res.detail.userInfo) {
      app.setUserInfo(res);
      wx.switchTab({
        url: '/pages/user/index'
      })
    }
  }
})