var app = getApp()
var token
Page({
  data: {
    userInfo: {},
    userService: [
      {
        name: "我的砍价",
        icon: "daojianfu",
        link: "../bargain/order/index",
        color:"#FF0C4B"
      },
      {
        name: "我的拼团",
        icon: "shehuituanti",
        link: "../group/order/index",
        color: "#FFB80C"
      },
      {
        name: "我的代言",
        icon: "tableshare",
        link: "../user/speak",
        color: "#00B9FD"
      },
      {
        name: "增值发票",
        icon: "fapiaoguanli",
        link: "../invoice/create",
        color: "#FD4100"
      },
      {
        name: "收货地址",
        icon: "dizhi",
        link: "../address/index",
        color: "#7ACF00"
      },

    ],
  },
  bindProfile: function () {
    wx.navigateTo({
      url: '../profile/profile'
    })
  },
  bindMoney: function () {
    wx.navigateTo({
      url: '../account/account'
    })
  },
  bindOrder: function () {
    wx.navigateTo({
      url: "../user_order/order"
    })
  },

  onLoad:function(option){
    app.editTabBar();
    
  },

  onShow: function () {
    app.hideTabbar();
    var that = this
    // 获取用户数据
    this.setData({
      userInfo: app.globalData.userInfo,
    })
    var token = wx.getStorageSync('token')
    wx.request({
      url: app.apiUrl("user"),
      data: {
        per_page: "10",
        page: "1"
      },
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      method: "POST",
      success: function (res) {
        that.setData({
          recommend: res.data.data.best_goods,
          orderNum: res.data.data.order
        })
      }
    })
    //加载中
    this.loadingChange()
  },

  loadingChange() {
    this.setData({
      hidden: false
    })
    setTimeout(() => {
      this.setData({
        hidden: true
      })
    }, 500)
  },

  //获取点击的id值
  siteDetail: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index;
    // console.log(index)
    var goodsId = that.data.recommend[index].goods_id;
    //  console.log(goodsId)
    wx.navigateTo({
      url: "../goods/index?objectId=" + goodsId
    });
  },
  invoiceNav: function (e) {
    var that = this
    token = wx.getStorageSync('token')
    wx.request({
      url: app.apiUrl("user/invoice/detail"),
      method: "POST",
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      success: function (res) {
        if (res.data.data != false) {
          wx.navigateTo({ url: '../invoice/detail' })
        } else {
          wx.navigateTo({ url: '../invoice/create' })
        }
        that.setData({
          invoices: res.data.data
        })
      }
    })
  },
  userAddress: function (e) {
    // wx.setStorageSync('userAddress', { from: "address" })
    wx.navigateTo({ url: '../address/index' })
  },
  onShareAppMessage: function () {
    return {
      title: '小程序首页',
      desc: '小程序本身无需下载，无需注册，不占用手机内存，可以跨平台使用，响应迅速，体验接近原生App',
      path: '/pages/user/user'
    }
  },

  //cyc
  //下拉刷新完后关闭
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
  },
  getUserInfo:function(res){
    var userinfo = res.detail.userInfo;
    app.setUserInfo(res.detail);
    this.setData({
      userInfo: res.detail.userInfo
    })
  },
  getWxUserInfo:function(){
    token = wx.getStorageSync('token');
    wx.request({
      url: app.apiUrl("user/getWxUserInfo"),
      method: "POST",
      header: {
        'Content-Type': 'application/json',
        'X-ECTouch-Authorization': token
      },
      success: function (res) {
        console.log(res)
      }
    })
  },
  //cyc
})